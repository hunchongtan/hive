//
//  DemoApp.swift
//  Demo
//
//  Created by user on 7/9/23.
//

import SwiftUI

@main
struct DemoApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
